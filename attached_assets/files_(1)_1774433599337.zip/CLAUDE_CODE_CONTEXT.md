# AUTORESEARCH EVAL SYSTEM — Setup & Operations Guide

## What this is

Research Everything (researcheverything.xyz) is a VC deal intelligence platform. One of its features is an AI-powered "data agent" that generates charts from natural language — a user looks at a company in their deal pipeline, asks "show me Morpho's weekly borrow volume," and the system writes SQL, fetches data from Dune Analytics, and renders a chart.

The data agent gets things right about 60-70% of the time. The autoresearch eval system makes it self-improving by:
1. Logging every query attempt (successes, retries, failures) for analysis
2. Cross-validating Dune SQL results against DeFiLlama reference data before caching
3. Running an autonomous benchmark loop: test 350 cases → score against ground truth → analyze failures → generate prompt improvements → apply them → repeat

The agent (Claude) doesn't change. The model weights are frozen. What changes is the context the model sees — rules in its system prompt, proven query examples, routing preferences. The benchmark discovers what context the agent needs to succeed, and provides it automatically.

## Architecture

```
Production App (Replit) ──── reads rules from ──── PostgreSQL DB
                                                        │
Benchmark Runner (this machine) ── writes rules to ─────┘
```

Both environments connect to the same PostgreSQL database. Rules written by the benchmark are immediately live in production — no deployment needed. The production app's `loadLearningsForPrompt()` function reads from `system_learnings` on every request.

The benchmark runner is a standalone script. It does NOT need the full app running. It imports specific modules:
- `server/storage.ts` — database operations (Drizzle ORM)
- `server/mpp-client.ts` — Claude API calls via MPP micropayment channels
- `server/defillama-client.ts` — DeFiLlama API (free, no key)
- `server/dune-client.ts` — Dune Analytics API

## Repository structure (relevant files only)

```
bookmark/
├── .env                          # Environment variables (you create this)
├── shared/
│   └── schema.ts                 # Database table definitions (Drizzle)
├── server/
│   ├── db.ts                     # PostgreSQL connection
│   ├── storage.ts                # All database operations
│   ├── mpp-client.ts             # Claude API client (via MPP/Tempo)
│   ├── dune-client.ts            # Dune Analytics API client
│   ├── defillama-client.ts       # DeFiLlama API client
│   ├── data-agent.ts             # The AI chart agent (production code)
│   ├── routes.ts                 # Express API routes (includes admin endpoints)
│   └── benchmark/
│       ├── cli.ts                # ★ Main entry point — run this
│       ├── seed.ts               # Generates benchmark test cases from DeFiLlama
│       ├── runner.ts             # The autoresearch loop
│       ├── eval.ts               # Scoring function (magnitude, trend, MAPE)
│       ├── cross-validate.ts     # Cross-source validation (Dune vs DeFiLlama)
│       └── index.ts              # Barrel export
├── drizzle.config.ts             # Database migration config
├── package.json
└── tsconfig.json
```

## Environment variables required

```
DATABASE_URL=postgresql://...     # PostgreSQL connection string (same as production Replit)
DUNE_API_KEY=...                  # Dune Analytics Pro API key
MPP_SERVER_WALLET_KEY=...         # Private key for MPP micropayment wallet (pays for Claude API calls)
```

These are stored in Replit's Secrets tab. The user will paste them.

## Database tables (created by this system)

These 4 tables are NEW — created by running `npx drizzle-kit push`:

- `query_attempts` — logs every chart generation attempt (first try, retries, fallbacks)
- `benchmark_cases` — ground truth test cases (protocol + metric + natural language query + reference source)
- `benchmark_runs` — one row per benchmark execution (accuracy, config version, improvements applied)
- `benchmark_case_results` — per-case scores within a run

These tables already exist and are used by the benchmark:

- `proven_queries` — cached working SQL queries (Layer 2 of the learning system)
- `system_learnings` — prompt rules auto-generated from failures (Layer 3)

## Setup steps (in order)

### 1. Clone and install
```bash
git clone https://github.com/polecalmer/bookmark.git
cd bookmark
npm install
npm install dotenv
```

### 2. Create .env file
Create `.env` in the repo root with the three environment variables.

### 3. Verify the benchmark files exist
Check that `server/benchmark/cli.ts` exists. If the benchmark branch hasn't been merged yet, the files need to be copied in. The user will provide them or specify which branch to checkout.

### 4. Push database schema
```bash
npx drizzle-kit push
```
This creates the 4 new tables. Non-destructive — won't affect existing tables or data.

If this fails with a connection error, the DATABASE_URL may need `?sslmode=require` appended.

### 5. Verify connectivity
```bash
npx tsx server/benchmark/cli.ts status
```
Expected output:
```
SYSTEM STATUS
  Benchmark cases: 0
  Active rules: <some number>
  No completed runs yet.
```

If this fails:
- "DATABASE_URL must be set" → .env file not loaded or dotenv not installed
- Connection refused → DATABASE_URL is wrong or Replit DB doesn't allow external connections
- "MPP_SERVER_WALLET_KEY not set" → .env file is missing this value

### 6. Seed the benchmark
```bash
npx tsx server/benchmark/cli.ts seed
```
Takes 2-3 minutes. Calls DeFiLlama API to discover top 100 protocols and which metrics each one has. Generates ~300-400 test cases.

Verify: `npx tsx server/benchmark/cli.ts status` should show `Benchmark cases: 300-400`.

### 7. Run a small test
```bash
npx tsx server/benchmark/cli.ts run --subset 10 --verbose --dry-run
```
Takes ~10 minutes. Runs 10 random test cases through the agent (Claude Opus via MPP), scores against DeFiLlama reference data, prints results. `--dry-run` means no improvements are applied.

Expected output: accuracy between 50-80%, individual case scores, proposed improvements.

### 8. Run with improvements applied
```bash
npx tsx server/benchmark/cli.ts run --subset 30 --verbose
```
Takes ~25 minutes, costs ~$20-25 in MPP/Claude. Applies proposed improvements to `system_learnings` table. Production app picks them up on the next chart request.

### 9. Full benchmark
```bash
npx tsx server/benchmark/cli.ts full-cycle
```
Takes 2-3 hours, costs ~$150-200. Seeds if needed, runs all ~350 cases, analyzes, applies improvements, prints full report.

For long runs, use `nohup` to survive terminal disconnection:
```bash
nohup npx tsx server/benchmark/cli.ts full-cycle > benchmark-run.log 2>&1 &
tail -f benchmark-run.log
```

## CLI commands reference

```bash
# Seed benchmark cases from DeFiLlama
npx tsx server/benchmark/cli.ts seed [--dry-run] [--limit N]

# Run benchmark evaluation
npx tsx server/benchmark/cli.ts run [--subset N] [--difficulty easy|standard|hard] [--dry-run] [--verbose]

# Show system status and run history
npx tsx server/benchmark/cli.ts status

# Show failure details for a specific run (or latest if no ID given)
npx tsx server/benchmark/cli.ts failures [runId]

# Show production query failure patterns (from real user traffic)
npx tsx server/benchmark/cli.ts observability [--days N]

# Full cycle: seed if needed + run all cases + apply improvements
npx tsx server/benchmark/cli.ts full-cycle [--subset N]
```

## How the benchmark works internally

1. Loads test cases from `benchmark_cases` table
2. For each case:
   a. Builds context (DeFiLlama slug, few-shot examples from `proven_queries`, rules from `system_learnings`)
   b. Calls Claude Opus to generate a chart plan (data source + SQL/config)
   c. Executes the plan (runs SQL on Dune, or fetches from DeFiLlama/CoinGecko)
   d. If execution fails with an infrastructure error (rate limit, timeout), retries twice with backoff
   e. If 5 consecutive infra errors occur, circuit breaker aborts the run
   f. Fetches reference data from DeFiLlama for the same protocol+metric
   g. Scores agent output vs reference: magnitude match (40%), trend match (20%), shape/MAPE (40%)
3. After all cases scored:
   a. Filters out infrastructure errors (only analyzes agent failures)
   b. Groups agent failures by protocol, metric type, error type
   c. Feeds failure analysis to Claude Opus asking for improvement proposals
   d. Each improvement is a structured rule (e.g., "DeFiLlama slug for Morpho is 'morpho-blue'")
   e. Rules are inserted into `system_learnings` table
4. Production app reads `system_learnings` on every request — rules are live immediately

## How the scoring works

Each test case gets a score from 0 to 1:

- **Magnitude (40%)**: Is the agent's latest data point value within tolerance of the reference? (e.g., within 20% for TVL, 30% for revenue)
- **Trend (20%)**: Is the data going in the same direction? (both up, both down, or both flat)
- **Shape (40%)**: Mean Absolute Percentage Error across overlapping time periods. 0% MAPE = perfect, 100% MAPE = completely wrong.

Score ≥ 0.5 = pass. Overall accuracy = passes / total cases.

## What the improvements look like

The runner proposes rules like:
- `[slug_hint]` "DeFiLlama slug for Morpho is 'morpho-blue' not 'morpho'" 
- `[table_warning]` "lending.repay does not exist in Dune — use lending.borrow"
- `[routing_override]` "For lending protocol revenue, prefer dune-sql over DeFiLlama (DeFiLlama returns zeros)"
- `[sql_pattern]` "Always filter amount_usd > 0 in lending.borrow queries"

These are written to `system_learnings` and injected into the agent's system prompt on every production request.

## Error handling and resilience

The runner distinguishes between **agent errors** (wrong SQL, bad column names, wrong slugs — the agent's fault) and **infrastructure errors** (rate limits, timeouts, payment failures, network issues — not the agent's fault).

**Error classification**: Every failure is pattern-matched against known infrastructure signatures (429, timeout, ECONNREFUSED, MPP payment errors, etc.). Anything that doesn't match is classified as an agent error.

**Retry with backoff**: Infrastructure errors get retried twice with exponential backoff (10s, 20s). Agent errors don't retry — bad SQL gives bad SQL again.

**Circuit breaker**: If 5 consecutive cases fail with infrastructure errors, the run aborts. This prevents burning money when Dune is down or the MPP wallet is empty. Partial results are saved — cases completed before the abort are in the database.

**Accuracy excludes infra errors**: If 300 cases ran successfully and 50 had infra errors, accuracy is calculated from the 300. The headline number measures agent quality, not API reliability.

**Improvement analysis excludes infra errors**: Rule proposals are based only on agent failures. The system won't propose "avoid Dune SQL" because Dune was rate-limited during one run.

**What to do when a run aborts**:
1. Check the error message — it tells you what failed (rate limit, payment, network)
2. Fix the underlying issue (wait for rate limit to reset, fund the MPP wallet, check network)
3. Re-run. Completed cases are already saved, but the run itself is marked as "failed" so a new full run is needed.

## Common issues

### "Cannot find module" errors when running CLI
Run `npm install` — dependencies aren't installed.

### Schema push fails
Ensure DATABASE_URL includes `?sslmode=require` if connecting to a cloud Postgres.

### Benchmark cases all score 0
Check that DUNE_API_KEY is valid and has credits. If all dune-sql cases fail execution, the Dune key may be expired.

### MPP payment errors  
The MPP_SERVER_WALLET_KEY wallet may be out of funds. Check the wallet balance. Each Opus call costs ~$0.30-0.50.

### Very low accuracy on first run
Expected! The first run establishes a baseline. Run 2-3 cycles and accuracy should improve significantly as rules accumulate.

### Run takes too long / want to stop
Ctrl+C (or kill the process). Partial results are saved to the database — the run will show as status "running" but individual case results are already recorded. You can view them with `failures <runId>`.

## Cost model

| Operation | Claude (MPP) cost | Dune cost | Time |
|---|---|---|---|
| Seed | $0 | $0 | 2-3 min |
| 10-case run | ~$5-8 | ~$0.50 | ~10 min |
| 30-case run | ~$15-25 | ~$2-3 | ~25 min |
| 50-case run | ~$25-40 | ~$3-5 | ~40 min |
| Full 350-case run | ~$150-200 | ~$10-15 | ~2-3 hr |

All LLM calls use Claude Opus for maximum quality.
