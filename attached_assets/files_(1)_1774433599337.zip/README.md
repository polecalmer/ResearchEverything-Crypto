# Autoresearch Eval System — Deployment Guide

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│  PRODUCTION REPL (your existing app)                        │
│                                                             │
│  • Serves users normally                                    │
│  • Logs every chart attempt to query_attempts               │
│  • Cross-validates Dune results before saving proven queries│
│  • Admin endpoints for quick benchmark runs                 │
│  • Reads rules from system_learnings (auto-updated)         │
└─────────────────────┬───────────────────────────────────────┘
                      │
                      │  Shared PostgreSQL
                      │
┌─────────────────────┴───────────────────────────────────────┐
│  BENCHMARK REPL (dedicated, separate)                       │
│                                                             │
│  • Runs full 350-case eval (2-3 hours, uninterrupted)       │
│  • Writes improvements to system_learnings                  │
│  • Production app picks them up on next request             │
│  • CLI interface for all operations                         │
└─────────────────────┬───────────────────────────────────────┘
                      │
                      │  Same DB connection
                      │
┌─────────────────────┴───────────────────────────────────────┐
│  LOCAL MACHINE (your laptop)                                │
│                                                             │
│  • Deep-dive analysis of failures                           │
│  • Manual rule review before applying                       │
│  • Ad-hoc queries against query_attempts                    │
└─────────────────────────────────────────────────────────────┘
```

All three environments connect to the same database. Rules written by the benchmark are immediately live in production. No deployment step needed for rule updates.

## File manifest

### Modified
- `shared/schema.ts` — 4 new tables
- `server/storage.ts` — 15 new storage methods
- `server/data-agent.ts` — Query attempt logging + cross-validation gate
- `server/routes.ts` — Admin endpoints for benchmark control

### New
- `server/benchmark/cross-validate.ts` — Checks Dune results against DeFiLlama
- `server/benchmark/eval.ts` — Scoring function (magnitude/trend/MAPE)
- `server/benchmark/seed.ts` — Generates test cases from DeFiLlama
- `server/benchmark/runner.ts` — The autoresearch loop (Opus for all LLM calls)
- `server/benchmark/cli.ts` — Standalone CLI for all operations
- `server/benchmark/index.ts` — Barrel export

## Step-by-step deployment

### 1. Merge code and push schema
In your production Repl shell:
```bash
npx drizzle-kit push
```
Creates 4 tables. Non-destructive. Deploy the code — cross-validation and query attempt logging go live immediately.

### 2. Set up the benchmark Repl
Create a new Repl. Clone your repo. Set environment variables:
```
DATABASE_URL=<same as production>
DUNE_API_KEY=<same>
ANTHROPIC_API_KEY=<or MPP equivalent>
```
Test: `npx tsx server/benchmark/cli.ts status`

### 3. Seed → First run → Full cycle
```bash
npx tsx server/benchmark/cli.ts seed
npx tsx server/benchmark/cli.ts run --subset 20 --verbose --dry-run
npx tsx server/benchmark/cli.ts run --subset 50 --verbose
npx tsx server/benchmark/cli.ts full-cycle
```

## Admin API (production Repl)

All require auth + admin role.

```
POST /api/admin/benchmark/seed?protocolLimit=100
POST /api/admin/benchmark/run?subset=30&dryRun=false&difficulty=standard
GET  /api/admin/benchmark/status
GET  /api/admin/benchmark/failures/:runId
GET  /api/admin/benchmark/observability?days=30
```

## CLI (benchmark Repl or local)

```bash
npx tsx server/benchmark/cli.ts seed [--dry-run] [--limit N]
npx tsx server/benchmark/cli.ts run [--subset N] [--difficulty X] [--dry-run] [--verbose]
npx tsx server/benchmark/cli.ts status
npx tsx server/benchmark/cli.ts failures [runId]
npx tsx server/benchmark/cli.ts observability [--days N]
npx tsx server/benchmark/cli.ts full-cycle [--subset N]
```

## Recommended cadence

**Week 1**: Deploy, seed, `run --subset 20 --dry-run`, review, `run --subset 50`, check prod logs.
**Week 2-4**: Monday regression check (100 easy), Wednesday full eval (100 all), Friday observability review.
**Week 5+**: Weekly `full-cycle`, monthly re-seed, quarterly rule pruning.

## Cost (all Opus)

| Operation | LLM | Dune | Time |
|---|---|---|---|
| Seed | $0 | $0 | 2-3 min |
| 20-case | ~$10-15 | ~$1-2 | ~15 min |
| 50-case | ~$25-40 | ~$3-5 | ~40 min |
| Full 350-case | ~$150-200 | ~$10-15 | ~2-3 hr |
| Cross-validation (per prod request) | $0 | $0 | ~0.5s |
