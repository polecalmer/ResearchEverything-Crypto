# Autoresearch Eval System — Deployment Guide

## What's in this patch

### Modified files (apply patch or replace)
- `shared/schema.ts` — Added 4 tables: `query_attempts`, `benchmark_cases`, `benchmark_runs`, `benchmark_case_results`
- `server/storage.ts` — Added 15 new storage methods for the eval system
- `server/data-agent.ts` — Wired in query attempt logging + cross-source validation gate before proven_query saves

### New files
- `server/benchmark/cross-validate.ts` — Compares Dune results against DeFiLlama reference data
- `server/benchmark/eval.ts` — Scoring function (magnitude, trend, shape/MAPE) — your val_bpb
- `server/benchmark/seed.ts` — Auto-generates 300-400 test cases from DeFiLlama's top 100 protocols
- `server/benchmark/runner.ts` — The autoresearch loop: run benchmark → analyze → propose improvements → apply
- `server/benchmark/index.ts` — Barrel export

## Deployment steps

### 1. Push schema to database
```bash
npx drizzle-kit push
```
This creates the 4 new tables. Non-destructive — won't touch existing tables.

### 2. Seed the benchmark
```bash
# Dry run first (no DB writes)
npx tsx server/benchmark/seed.ts --dry-run

# Actually seed
npx tsx server/benchmark/seed.ts
```
Takes ~2-3 minutes. Hits DeFiLlama to discover which protocols have fees/revenue/volume data. Generates ~300-400 test cases.

### 3. Run a benchmark
```bash
# Small subset first (10 cases, verbose output)
npx tsx server/benchmark/runner.ts --subset 10 --verbose --dry-run

# Full benchmark (all cases, apply improvements)
npx tsx server/benchmark/runner.ts --verbose

# Analyze previous run without re-executing
npx tsx server/benchmark/runner.ts --analyze-only
```

### 4. What happens automatically (no action needed)
Once deployed, every chart request now:
- Logs every attempt (first try, retries, fallbacks) to `query_attempts`
- Cross-validates Dune SQL results against DeFiLlama before saving to `proven_queries`
- Blocks likely-wrong results from entering the proven query bank

### 5. Set up recurring benchmark (optional)
Add a cron job or scheduled task:
```bash
# Weekly benchmark + improvement cycle
0 3 * * SUN npx tsx server/benchmark/runner.ts --verbose >> /var/log/benchmark.log 2>&1
```

## Cost estimates
- Seeding: Free (DeFiLlama API only)
- Full benchmark (400 cases): ~$40-60 in LLM cost + $4-8 Dune credits, ~2-3 hours
- 50-case subset: ~$5-10, ~20 minutes  
- Cross-validation per production request: ~0.5s latency added, $0 (DeFiLlama is free)

## Architecture summary

```
Production request → data-agent.ts
  │
  ├─ [NEW] Logs every attempt to query_attempts table
  │
  ├─ [NEW] Cross-validates results against DeFiLlama
  │         before saving to proven_queries
  │
  └─ All existing logic unchanged (retry loop, fallback, etc.)

Weekly benchmark run → runner.ts
  │
  ├─ Loads test cases from benchmark_cases
  │
  ├─ Runs each through the agent pipeline
  │
  ├─ Scores against DeFiLlama reference data (eval.ts)
  │
  ├─ Analyzes failure patterns
  │
  ├─ Asks LLM to propose rule improvements
  │
  └─ Applies improvements to system_learnings table
      (which gets injected into the agent's prompt)
```
